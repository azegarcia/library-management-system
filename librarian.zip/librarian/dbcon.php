<?php
$conn = mysqli_connect('localhost','root','','batstateu_lib_dms') or die(mysqli_error());
?>