<li>		
					<a href="borrow.php"  data-toggle="dropdown" ><i class="icon-gear icon-large"></i> Setting</a>
					<ul class="dropdown-menu">
					<li><a href="users.php"><i class="icon-user icon-large"></i>&nbsp;Users</a></li>
					<li><a href="logout.php"><i class="icon-signout icon-large"></i>&nbsp;Logout</a></li>
					</ul>
					</li>