<?php include('header.php'); ?>
<?php include('session.php'); ?>
<?php include('navbar_books.php'); ?>
    <div class="container">
		<div class="margin-top">
			<div class="row">	
			<div class="span12">	
		
			<p><a href="documents.php" class="btn btn-info"><i class="icon-arrow-left icon-large"></i>&nbsp;Back</a></p>
	<div class="addstudent">
	<div class="details">Please Enter Details Below</div>			
	<form class="form-horizontal" method="POST" action="document_save.php" enctype="multipart/form-data">
		&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
 		Select a file:
		&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
  		<input type="file" name="fileToUpload" id="fileToUpload">
		<div class="control-group">
		<br>
			<label class="control-label" for="inputEmail">Description:</label>
			<div class="controls">
				<input type="text"  class="span4" id="inputPassword" name="author"  placeholder="Add Description" required>
			</div>
		</div>
		<div class="control-group">
			<label class="control-label" for="inputPassword">Classification:</label>
			<div class="controls">
			<select name="status" required>
				<option></option>
				<option>Administration</option>
				<option>Administrative Staff</option>
				<option>Collection Development, Organization and Preservation</option>
				<option>Services and Utilization</option>
				<option>Physical Set-up and Facilities</option>
				<option>Financial Support</option>
				<option>Linkages</option>
				<option>ISO Documents</option>
			</select>
			</div>
		</div>
		<div style="text-align:right; width:100%; padding:0;">
			<input type="submit" value="Upload File" name="submit">
			&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
		</div>
	</form>				
			</div>		
			</div>		
			</div>
		</div>
    </div>
<?php include('footer.php') ?>